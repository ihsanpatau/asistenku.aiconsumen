// asistenku.pro — Shared client script (Supabase Auth + UI helpers)
(function(){
  const SUPABASE_URL = 'https://dkpztybbcvvzatgwhano.supabase.co';
  const SUPABASE_KEY = 'sb_publishable_yYIlVG0GWf85R3wK_xjhfQ_1gqucStm';
  if (window.supabase && !window.sb) {
    window.sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' }
    });
  }
})();

// Helpers
function $(sel, root){ return (root||document).querySelector(sel); }
function $$(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }
function showError(el, msg){ if(!el)return; el.textContent = msg; el.classList.add('show'); }
function clearMsg(el){ if(!el)return; el.textContent=''; el.classList.remove('show'); }
function togglePw(btn){
  const wrap = btn.closest('.input-group');
  const inp = wrap && wrap.querySelector('input');
  if(!inp)return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.innerHTML = inp.type === 'password'
    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'
    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
}

// Guard page: require auth
async function requireAuth(){
  // Preview mode: bypass auth for demo screenshots (?preview=1)
  const url = new URL(window.location.href);
  if(url.searchParams.get('preview') === '1'){
    return { user: { email: 'demo@asistenku.pro', user_metadata: { full_name: 'Andi Wijaya' } } };
  }
  try{
    const { data: { session } } = await window.sb.auth.getSession();
    if(!session){ window.location.href = 'login.html'; return null; }
    return session;
  } catch(e){ window.location.href = 'login.html'; return null; }
}

// Guard page: redirect if already signed in
async function redirectIfAuthed(){
  try{
    const { data: { session } } = await window.sb.auth.getSession();
    if(session){ window.location.href = 'home.html'; }
  } catch(e){}
}

// Login form handler
async function handleLogin(evt){
  evt.preventDefault();
  const form = evt.target;
  const err = $('#authError');
  const btn = form.querySelector('button[type=submit]');
  clearMsg(err);
  const email = form.email.value.trim();
  const password = form.password.value;
  if(!email || !password){ showError(err, 'Email dan kata sandi wajib diisi.'); return; }
  btn.disabled = true; const origHtml = btn.innerHTML; btn.innerHTML = '<span class="spinner"></span> Memproses...';
  try{
    const { data, error } = await window.sb.auth.signInWithPassword({ email, password });
    if(error) throw error;
    window.location.href = 'home.html';
  } catch(e){
    showError(err, e.message === 'Invalid login credentials' ? 'Email atau kata sandi salah.' : (e.message || 'Login gagal.'));
    btn.disabled = false; btn.innerHTML = origHtml;
  }
}

// Register form handler
async function handleRegister(evt){
  evt.preventDefault();
  const form = evt.target;
  const err = $('#authError');
  const ok = $('#authSuccess');
  const btn = form.querySelector('button[type=submit]');
  clearMsg(err); clearMsg(ok);
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const phone = (form.phone.value || '').trim();
  const password = form.password.value;
  const confirm = form.confirmPassword.value;
  const agreed = form.agree.checked;
  if(!name || !email || !password){ showError(err, 'Nama, email, dan kata sandi wajib diisi.'); return; }
  if(password.length < 6){ showError(err, 'Kata sandi minimal 6 karakter.'); return; }
  if(password !== confirm){ showError(err, 'Konfirmasi kata sandi tidak cocok.'); return; }
  if(!agreed){ showError(err, 'Kamu harus menyetujui Syarat & Ketentuan.'); return; }
  btn.disabled = true; const origHtml = btn.innerHTML; btn.innerHTML = '<span class="spinner"></span> Mendaftar...';
  try{
    const { data, error } = await window.sb.auth.signUp({
      email, password,
      options: { data: { full_name: name, phone } }
    });
    if(error) throw error;
    if(data.user && !data.session){
      showError(ok, 'Pendaftaran berhasil! Silakan cek email untuk verifikasi lalu login.');
      ok.classList.add('show');
      setTimeout(()=>{ window.location.href='login.html'; }, 2500);
    } else {
      window.location.href = 'home.html';
    }
  } catch(e){
    showError(err, e.message || 'Pendaftaran gagal.');
    btn.disabled = false; btn.innerHTML = origHtml;
  }
}

// OAuth: Google
async function loginGoogle(){
  try{
    await window.sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin + '/home.html' } });
  } catch(e){ alert('Login Google gagal: ' + (e.message||e)); }
}
// OAuth: Apple
async function loginApple(){
  try{
    await window.sb.auth.signInWithOAuth({ provider: 'apple', options: { redirectTo: window.location.origin + '/home.html' } });
  } catch(e){ alert('Login Apple gagal: ' + (e.message||e)); }
}

// Sign out
async function signOut(){
  try{ await window.sb.auth.signOut(); } catch(e){}
  window.location.href = 'login.html';
}

// FAQ toggle
document.addEventListener('click', (e) => {
  const q = e.target.closest('.faq-q');
  if(q){ q.parentElement.classList.toggle('open'); }
});

// Simple chat interactivity (frontend mock only)
function attachChat(bodySel, formSel){
  const body = document.querySelector(bodySel);
  const form = document.querySelector(formSel);
  if(!body || !form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const ta = form.querySelector('textarea');
    const text = (ta.value || '').trim();
    if(!text) return;
    // user bubble
    const u = document.createElement('div');
    u.className = 'chat-msg user';
    u.innerHTML = '<div class="chat-bubble">'+ escapeHtml(text) +'</div>';
    body.appendChild(u);
    ta.value=''; ta.style.height='44px';
    body.scrollTop = body.scrollHeight;
    // fake AI response
    setTimeout(() => {
      const a = document.createElement('div');
      a.className = 'chat-msg';
      a.innerHTML = '<div class="av"><img src="assets/mascot.png"/></div><div class="chat-bubble">Terima kasih! Fitur AI sedang dalam tahap integrasi. Silakan kembali lagi setelah API key dihubungkan. ✨</div>';
      body.appendChild(a);
      body.scrollTop = body.scrollHeight;
    }, 700);
  });
}

function escapeHtml(s){ return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
